# mmhm-arcadia-requirement-skill

一套面向产品经理的 AI Agent Skill 集合，覆盖 **需求规范制定 → PRD 文档生成 → 高保真原型生成** 全链路。通过结构化追问、模块化模板、标准化产物协议，让 AI 成为你的"需求挖掘搭档"。

---

## 目录

- [Skills 概览](#skills-概览)
- [安装与配置](#安装与配置)
  - [1. 将 Skill 安装到 Agent](#1-将-skill-安装到-agent)
  - [2. 工作区目录准备](#2-工作区目录准备)
  - [3. 配置 BusyUi MCP Server（必须）](#3-配置-busyui-mcp-server必须)
  - [4. 可选：启动 mmhm-arcadia-requirement Server](#4-可选启动-mmhm-arcadia-requirement-server)
- [Skill 1: mmhm-arcadia-requirement-rules — 产物规范](#skill-1-mmhm-arcadia-requirement-rules--产物规范)
- [Skill 2: prd-generator — PRD 生成器](#skill-2-prd-generator--prd-生成器)
- [Skill 3: prototype-generator — 原型生成器](#skill-3-prototype-generator--原型生成器)
- [协作流程](#协作流程)
- [注意事项](#注意事项)

---

## Skills 概览

| Skill | 版本 | 一句话说明 |
|-------|------|-----------|
| `mmhm-arcadia-requirement-rules` | 1.0.0 | 全平台产物规范——文件协议、PRD 格式、原型规范、迭代数据、命令协议、校验规则 |
| `prd-generator` | 1.0.0 | 多轮 AI 追问挖掘需求，按模块化模板组装生成规范的 Markdown 需求文档 |
| `prototype-generator` | 1.0.0 | 读取需求文档，生成高保真可交互 HTML 原型（多页源文件 → 组装单 HTML） |

---

## 安装与配置

### 1. 将 Skill 安装到 Agent

在支持 Agent Skill 的 IDE（Qoder / Cursor / Trae 等）中，将本仓库作为 Skill 源导入。每个 `skills/` 子目录即为一个独立 Skill。

### 2. 工作区目录准备

在你的项目工作区中创建如下目录结构：

```
{workspace}/
├── products/          # 正式需求存放目录
│   └── {product-line}/
│       └── REQ-{id}-{slug}/
│           ├── requirement.md
│           ├── prototype-web.html      # 可选
│           └── prototype-mobile.html   # 可选
├── archive/           # 归档需求目录
├── drafts/            # 需求池草稿目录
├── .sprints.json      # 迭代元数据（自动生成）
└── .design-system.json # 自定义设计系统（可选）
```

### 3. 配置 BusyUi MCP Server（必须）

所有使用本 Skill 的用户**必须**配置 `busy-ui-mcp`，它是公司统一组件库 [BusyUi](https://busy-fe.hnlshm.com/busy-ui/) 的 MCP 接口。原型生成器通过它获取组件文档、样式 Token、页面 Recipe 等规范，确保生成的原型与前端组件库保持一致。

在项目根目录创建 `.qoder/mcp.json`（如已存在则合并），写入以下配置：

```json
{
  "mcpServers": {
    "busy-ui-mcp": {
      "command": "npx",
      "args": [
        "--yes",
        "--registry=https://npm.hnlshm.com/",
        "--package=@busy-fe/ui-mcp",
        "busy-ui-mcp"
      ]
    }
  }
}
```

配置完成后重新加载 IDE 窗口即可生效。MCP Server 提供以下 6 个工具：

| 工具 | 说明 |
|------|------|
| `get_agent_guide` | 读取 BusyUi 组件库总览、Skill 和 Capability Pack 摘要，建立选型规则 |
| `get_style_contract` | 读取样式契约、CSS Token 和 Element Plus 对齐级别 |
| `search_components` | 在版本化 Capability Pack 中搜索组件（先用它选型） |
| `get_component_doc` | 读取选定组件的精简文档、TypeScript 声明、使用模式和 Demo |
| `get_page_recipe` | 读取页面组合 Recipe（如 list、crud-list），避免自行拼装不一致的结构 |
| `check_ui_project` | 检查宿主项目的 BusyUi 安装版本、完整性和废弃组件用法 |

### 4. 可选：启动 mmhm-arcadia-requirement Server

如果需要自动导入功能，确保 mmhm-arcadia-requirement Server 运行在 `http://arcadia.busyming.com`。

---

## Skill 1: mmhm-arcadia-requirement-rules — 产物规范

### 定位

这是整个平台的**规范层**（唯一规范源），定义了所有产物的格式、接口、校验规则。它不是一个"执行型"Skill，而是被其他 Skill 引用的规范文档。

### 涵盖内容

| 章节 | 内容 |
|------|------|
| §1 文件协议 | 目录结构、命名规则、ID 分配算法、Slug 生成算法 |
| §2 需求文档规范 | YAML Front Matter 字段定义、读取容错规则、正文结构建议、草稿文档规范 |
| §3 原型规范 | HTML 文件格式、DesignSystem 接口定义、交互要求、保真度要求 |
| §4 迭代数据规范 | `.sprints.json` 结构、迭代状态、归档流程、API 端点定义 |
| §5 命令协议 | `/prd-new`、`/prd-update` 等命令格式和执行流程 |
| §6 元数据校验规则 | 导入校验清单、修复方式、导入接口规范 |
| §7 产物放置规则 | 文件路径、归档路径、命名规范 |

### 使用方式

在 Agent 对话中调用：

```
/mmhm-arcadia-requirement-rules
```

Agent 会加载完整规范作为上下文，后续生成的产物将自动遵循。

### Demo：用命令创建需求

```
用户：/prd-new 用户登录功能，支持手机号和邮箱两种方式

Agent 执行流程：
1. 分配 ID → REQ-000001
2. 生成 Slug → phone-email-login
3. 创建目录 → products/{product-line}/REQ-000001-phone-email-login/
4. 启动 prd-generator 进行多轮追问
5. 组装 requirement.md
6. 启动 prototype-generator 生成原型（除非 --skip-prototype）
```

### Demo：支持的命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `/prd-new <描述>` | 创建新需求 | `/prd-new 会员积分兑换功能 --platform both --priority P1` |
| `/prd-update <ID> <描述>` | 更新需求 | `/prd-update REQ-000001 增加微信登录方式` |
| `/prd-status <ID> <状态>` | 修改状态 | `/prd-status REQ-000001 开发中` |
| `/prd-priority <ID> <级别>` | 修改优先级 | `/prd-priority REQ-000001 P0` |
| `/prd-sprint <ID> <迭代>` | 分配迭代 | `/prd-sprint REQ-000001 迭代2` |
| `/prd-archive <ID>` | 归档需求 | `/prd-archive REQ-000001` |

---

## Skill 2: prd-generator — PRD 生成器

### 定位

你的"需求挖掘搭档"。给定一个模糊需求 → AI 多轮追问（3~5 轮）→ 逐步产出阶段物 → 最终组装为规范的需求文档。

### 核心特点

- **追问驱动**：不是你说一句就生成，最少 3 轮深度追问
- **每轮有阶段产物**：让你确认方向正确再继续
- **模块化模板**：10 个可选模块 + 3 套预置模板 + 自定义模板
- **知识底座集成**：可对接知识库，参考历史规则和决策
- **矛盾检测**：自动发现需求中的冲突并追问

### 使用步骤

**Step 1：选择模板**

```
用户：/prd-generator 我要做一个智能客服功能

Agent：
📋 可用模板：
1. 轻量需求 — background + requirements + pages（小功能/优化类）
2. 标准需求 — background + goals + feature_map + requirements + pages + open_issues（常规功能）
3. 完整需求 — 全部10个模块（重大功能/新系统）
4. 自定义 — 从模块库中选择组装

请选择模板编号，或直接描述你的需求我来推荐。
```

**Step 2：多轮追问（R1~R5）**

```
Agent（R1 方向确认）：
> 智能客服，我先搞清楚几个关键问题：
> 1. 这解决什么问题？是减少人工客服工作量，还是提升用户自助解决率？
> 2. 目标用户是 C 端消费者还是 B 端商户？
> 3. 当前客服是怎么做的？纯人工？有没有 FAQ？

用户：主要减少人工，用户是 C 端消费者，现在有 FAQ 但没人看

Agent（R1 产物 + R2 追问）：
> 📝 第1轮产出：
> **项目背景**：C 端消费者咨询量大，现有 FAQ 使用率低，人工客服压力大。
> **需求概要**：AI 驱动的智能客服系统，优先推荐自助解决方案，无法解决时转人工。
>
> ✅ 请确认以上内容是否有遗漏或需要调整。
> 🔍 下一轮我想了解：
> 1. 核心场景有哪些？比如订单查询、售后退款、物流追踪？
> 2. 功能边界在哪？是否包含工单系统？
> 3. 有什么明确不做的事？

... （继续 R2→R3→R4→R5）
```

**Step 3：组装文档**

所有轮次完成后，Agent 将阶段产物组装为带 YAML Front Matter 的 `requirement.md`：

```yaml
---
id: "REQ-000001"
title: "智能客服功能"
status: "设计中"
priority: "P2"
platform: ["web"]
product_line: ["客服"]
sprint: ""
developer: ""
requester: ""
created: "2026-08-19"
updated: "2026-08-19"
due_date: ""
tags: []
---

# 智能客服功能

## 项目背景
...

## 需求说明
...

## 验收标准
- [ ] 用户发送消息后 3 秒内收到 AI 回复
- [ ] AI 无法解答时可一键转人工
- [ ] 支持常见 TOP5 场景的自助解决
```

**Step 4（可选）：导入 mmhm-arcadia-requirement**

```
Agent：是否自动导入到 mmhm-arcadia-requirement？
用户：是
Agent：POST /api/requirements/import → 导入成功，ID: REQ-000001
```

### 预置模板

| 模板 | 适用场景 | 包含模块 |
|------|---------|---------|
| **轻量需求** | 小功能、优化类 | background, requirements, pages |
| **标准需求** | 常规功能需求 | background, goals, feature_map, requirements, pages, open_issues |
| **完整需求** | 重大功能、新系统 | 全部 10 个模块 |

### 可选模块一览

| 模块 | 说明 |
|------|------|
| background | 项目背景：痛点、场景、为什么要做 |
| goals | 目标与指标：北极星指标、成功标准 |
| roles | 用户角色：角色定义、权限矩阵 |
| feature_map | 功能结构图：flowchart LR 树形图 |
| flowchart | 流程图：核心业务流程 |
| **requirements** | **需求说明（必选）**：用户故事、功能点、验收标准 |
| pages | 页面设计：页面列表、交互说明 |
| annotations | 标注说明：交互细节、校验规则、视觉提示 |
| data_model | 数据模型：核心实体、字段定义 |
| non_functional | 非功能需求：性能/安全/兼容/合规 |
| open_issues | 开放问题：待确认项、风险、依赖 |

---

## Skill 3: prototype-generator — 原型生成器

### 定位

读取需求文档（MD），生成高保真可交互的 HTML 原型。采用 **多页源文件 + 组装单 HTML** 架构。

### 核心特点

- **多页源文件架构**：每个页面一个独立 HTML 片段，AI 修改时上下文可控
- **组装为单文件输出**：`prototype-web.html` 可直接在浏览器打开
- **设计系统驱动**：纯 CSS + CSS 变量，不硬编码色值，不使用 Tailwind
- **BusyUi 组件库对齐**：通过 `busy-ui-mcp` 获取组件文档和页面 Recipe，确保原型与前端组件库一致
- **内置交互**：按钮 hover/active、表单 focus、页面切换、Toast 提示
- **标注支持**：需求文档中的标注说明会渲染为可视化角标

### 使用步骤

**Step 1：采集设计系统**

```
Agent：
🎨 设计系统：
- 检测到项目 .design-system.json → 使用项目配置
- 或使用 brand-hub-admin 默认色系（primary #0073ff + 中性灰）
是否使用该配置？还是提供自定义设计系统？
```

设计系统优先级：用户提供 > 项目 `.design-system.json` > mmhm-arcadia-requirement Settings > 默认色系

**Step 2：解析需求文档**

Agent 读取 `requirement.md`，提取页面列表、功能结构、业务流程、标注说明等。

**Step 3：确认页面列表**

```
Agent：
📐 根据需求文档，推导出以下页面：
1. 列表页 — 订单列表，含筛选/搜索/分页
2. 详情页 — 订单详情，含状态流转
3. 表单页 — 新建/编辑订单

请确认页面列表，或补充调整。
```

**Step 4：逐页生成源文件**

为每个页面生成独立的 HTML 片段到 `pages/` 目录：

```
pages/
├── page-list.html      ← 列表页
├── page-detail.html    ← 详情页
└── page-form.html      ← 表单页
```

**Step 5：组装为单 HTML**

将所有页面片段组装为 `prototype-web.html`，包含：
- 完整的设计系统 CSS 变量
- 侧边栏 + Header + 内容区布局
- 全局路由 `navigate()` 函数
- 页面切换 + 菜单高亮同步
- 标注角标渲染（如有标注说明）

**Step 6（可选）：导入 mmhm-arcadia-requirement**

```
若 http://arcadia.busyming.com 可达：
  → POST /api/requirements/{id}/prototype/import
  → 导入成功
```

### Demo：修改原型

```
用户：把列表页的筛选区增加一个日期范围筛选

Agent：
1. 定位 → pages/page-list.html
2. 修改源文件 → 在筛选区 grid 中添加日期范围组件
3. 重新组装 → 更新 prototype-web.html
```

### 设计规范要点

| 维度 | 规范 |
|------|------|
| 圆角 | 4px（卡片）/ 8px（按钮、输入框）/ 12px（Modal） |
| 背景 | 页面 #f5f5f5 / 卡片 #ffffff / 表头 #f5f7fa |
| 字体 | PingFang SC / 标题 18px-600 / 正文 14px-400 |
| 间距 | 紧凑 8px / 标准 16px / 宽松 24px |
| 布局 | 侧边栏 200px + Header 72px + 内容区 flex:1 |

---

## 协作流程

三个 Skill 形成完整的需求生产流水线：

```
┌──────────────┐     ┌──────────────┐     ┌───────────────────┐
│mmhm-arcadia- │     │ prd-generator│     │prototype-generator│
│requirement-rules│
│  （规范层）   │────▶│  （PRD 生成） │────▶│  （原型生成）      │
└──────────────┘     └──────────────┘     └───────────────────┘
      引用规范             产出文件                 读取文件
                     requirement.md          prototype-web.html
```

### 典型工作流

```
1. /prd-new 用户登录功能 --product-line 用户中心
   ↓
2. prd-generator 多轮追问 → 产出 requirement.md
   ↓
3. prototype-generator 读取 requirement.md → 产出 prototype-web.html
   ↓
4. 可选：自动导入 mmhm-arcadia-requirement 平台
```

---

## 注意事项

### 通用

1. **ID 自增**：`REQ-` ID 通过扫描 `products/` 和 `archive/` 目录自动分配，不要手动指定
2. **数组字段**：`platform`、`tags`、`product_line` 必须是 YAML 数组格式（`["web"]` 而非 `"web"`）
3. **状态/优先级来源**：执行命令前先通过 `GET /api/settings` 获取可用值列表，输入不在列表中的值会被提示

### prd-generator

1. **最少 3 轮追问**：不要期望一轮就生成完整文档，追问质量决定文档质量
2. **每轮确认**：Agent 每轮产出阶段物后会要求确认，认真检查再进入下一轮
3. **不用 mindmap**：功能结构图使用 `flowchart LR`，不使用 `mermaid mindmap`（渲染不稳定）
4. **非目标必写**：需求说明中必须包含"非目标"子章节，明确不做的事

### prototype-generator

1. **禁止 Tailwind**：所有样式使用 CSS 变量 `var(--brand-*)`，禁止 Tailwind CDN 或类名
2. **禁止硬编码色值**：所有颜色通过设计系统 Token 引用
3. **禁止 alert/confirm/prompt**：使用自定义 Toast/Modal 代替浏览器原生弹窗
4. **源文件保留**：`pages/` 目录下的源文件会保留，方便后续修改单个页面
5. **移动端需显式要求**：默认只生成 Web 端原型，需要移动端原型请明确说明
6. **必须配置 busy-ui-mcp**：所有原型设计必须参考 BusyUi 组件库规范，通过 MCP 获取组件文档、样式 Token 和页面 Recipe，禁止凭记忆硬写组件用法

### mmhm-arcadia-requirement 桥接

1. **Server 不可达时降级**：如果 `http://arcadia.busyming.com` 不可达，Skill 会保存文件到本地，不会报错
2. **导入接口**：需求导入用 `POST /api/requirements/import`，原型导入用 `POST /api/requirements/{id}/prototype/import`
