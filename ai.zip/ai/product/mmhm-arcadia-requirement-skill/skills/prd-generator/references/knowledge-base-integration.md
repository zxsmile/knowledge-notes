# 知识库集成规范

> prd-generator references — 知识库服务 API 规范、知识底座加载策略、追问引用规范

---

## 1. 知识库服务概览

- **服务地址**：`http://localhost:8080`
- **技术栈**：Spring Boot 2.7 + Milvus 2.4（向量数据库）+ Ollama/OpenAI Embedding
- **知识库 Schema 字段**：`id`, `layer`, `domain`, `project`, `phase`, `content`, `source`, `vector`

---

## 2. API 清单

### 2.1 获取可用业务域+项目列表

```
GET /api/knowledge/domains
```

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": [
    { "domain": "membership", "project": "member-growth", "description": "会员-成长值" },
    { "domain": "membership", "project": "member-rights", "description": "会员-权益" },
    { "domain": "membership", "project": "member-profile", "description": "会员-基础数据" },
    { "domain": "risk", "project": "risk-anti-fraud", "description": "风控-反欺诈" },
    { "domain": "brand", "project": "busyming-member-brandhub-admin", "description": "品牌-门店设计管理" }
  ]
}
```

**用途**：Step 1.5 第一步调用，展示给用户选择。

---

### 2.2 语义检索知识库

```
POST /api/knowledge/search
Content-Type: application/json
```

**请求体**：
```json
{
  "query": "查询文本（必填）",
  "topK": 50,
  "domain": "membership",
  "project": "member-growth",
  "layers": ["L1", "L2", "L3", "L4"],
  "phase": "phase2"
}
```

**字段说明**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `query` | String | 是 | 语义查询文本，与知识库内容做向量相似度匹配 |
| `topK` | Integer | 否 | 返回条数，默认 5；全量拉取时设为 50 |
| `domain` | String | 否 | 过滤业务域，如 `membership`、`risk`、`brand` |
| `project` | String | 否 | 过滤项目/模块，如 `member-growth`、`busyming-member-brandhub-admin` |
| `layers` | List | 否 | 过滤层级，可选 `L1`/`L2`/`L3`/`L4`，为空则不过滤 |
| `phase` | String | 否 | 过滤期数，如 `phase1`、`phase2` |

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "layer": "L1",
      "domain": "membership",
      "project": "member-growth",
      "phase": "phase1",
      "content": "单日成长值上限为500点，超过部分不计入当日成长值",
      "source": "成长值一期PRD_v1.0",
      "score": 0.87
    }
  ]
}
```

---

## 3. 四层知识库含义

| 层级 | 名称 | 存储内容 | 追问中的使用场景 |
|------|------|---------|----------------|
| L1 | 业务规则层 | 具体的业务规则、数值上限、校验条件、错误码 | R2 边界梳理（现有约束）、R4 细节填充（验收基线） |
| L2 | 设计决策层 | 设计背景、业务决策、为什么这样设计、痛点复盘 | R1 方向确认（历史背景）、冲突检测（决策依据） |
| L3 | 数据字典层 | 枚举定义、实体字段、接口字段说明 | R3 结构展开（复用已有模型）、R4 细节填充（字段扩展） |
| L4 | 流程编排层 | 业务流程、步骤编排、状态机流转 | R1 方向确认（历史流程）、R3 结构展开（流程复用）、R5 兜底（流程冲突） |

---

## 4. 现有 domain+project 清单

| Domain | Project | 说明 | 典型数据量 |
|--------|---------|------|----------|
| membership | member-growth | 会员-成长值系统（签到、订单奖励、评价奖励） | ~20条 |
| membership | member-rights | 会员-权益系统（等级权益、专属客服） | ~5条 |
| membership | member-profile | 会员-基础数据（手机号修改、状态管理） | ~3条 |
| risk | risk-anti-fraud | 风控-反欺诈（拦截规则、薅羊毛检测） | ~5条 |
| brand | busyming-member-brandhub-admin | 品牌-门店设计管理（设计任务、模板匹配、AI审核） | ~46条 |

---

## 5. 知识底座加载策略

### 全量拉取原则

**不做关键词搜索，而是一次性拉取整个 domain+project 的全部知识**。

- `topK` 设为 **50**，目标是尽可能拉全
- `query` 字段使用 `domain + project + 初始需求概要`，用于向量排序（非过滤）
- `domain` 和 `project` 字段用于**精确过滤**，确保只拉取目标项目的数据
- `layers` 设为 `["L1", "L2", "L3", "L4"]`，覆盖全部层级

### 加载失败降级

| 场景 | 处理方式 |
|------|---------|
| 知识库服务不可达（未启动） | 跳过 Step 1.5，提示"知识库服务未启动，将以纯对话模式进行" |
| domains 接口返回空 | 提示"知识库暂无历史数据，将以纯对话模式进行" |
| search 接口返回空 | 提示"该 domain+project 暂无历史知识"，继续追问流程 |
| 网络超时 | 重试一次，仍失败则降级为纯对话模式 |

---

## 6. 追问中的知识引用规范

### 如何引用

每一轮追问中，AI 在提问前应先引用相关知识底座内容作为上下文：

```
📝 第X轮产出：
[阶段产物]

✅ 请确认以上内容是否有遗漏或需要调整。
🔍 下一轮我想了解：
1. 根据历史知识底座，[L2 中的某个设计决策] 是这样设计的，本次是延续还是调整？
2. 现有 [L1 中的某个规则]，本次需求是否涉及修改？
```

### 冲突检测

当用户描述与历史知识矛盾时，必须明确指出：

```
⚠️ 注意：你刚才说的 [用户描述] 与历史知识存在冲突：
- 历史规则（[层级]）：[具体内容]
- 你的描述：[用户说的]
请确认：是修改历史规则，还是我理解有误？
```

### 在最终文档中的体现

历史知识引用章节中的"与新需求的关系"字段，取值范围：

| 关系 | 含义 |
|------|------|
| 延续 | 新需求沿用此规则/设计，不做修改 |
| 修改 | 新需求对此规则/设计进行了调整 |
| 冲突 | 新需求与此规则/设计存在矛盾，需进一步确认 |
| 补充 | 新需求在此规则/设计基础上新增了内容 |

---

## 7. 知识库写入 API（参考，不在 skill 流程中使用）

| 端点 | 说明 |
|------|------|
| `POST /api/knowledge/insert` | 插入单条知识 |
| `POST /api/knowledge/batch-insert` | 批量插入知识 |
| `POST /api/knowledge/sample-data` | 插入 membership+risk 样例数据 |
| `POST /api/knowledge/brand-data` | 插入 brand 域样例数据 |
| `POST /api/knowledge/collection/init` | 初始化 Collection |
| `GET /api/knowledge/collection/info` | 获取 Collection 信息 |
| `DELETE /api/knowledge/collection` | 删除 Collection |
