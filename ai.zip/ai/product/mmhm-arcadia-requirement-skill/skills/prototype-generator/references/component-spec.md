# prototype-generator references — maintenance-pc 组件规范
# 来源：maintenance-pc 工程（Naive UI + 项目业务组件）
# 参考工程路径：/Users/mmhm/busyming-engineer-prd/apps/maintenance-pc
# 业务组件：src/components/business（PageSearchCard / PageTableCard / PageFilterField / PageDialog / PageKeywordSearch）
# 高级组件：src/components/advanced（TableHeaderOperation / TableColumnSetting）
# 页面规范：docs/列表类型页面开发规则.md
# 所有组件使用 CSS 变量（var(--brand-*)），禁止硬编码色值

---

## 1. 组件总览

### 1.1 基础组件（Naive UI，原型用纯 CSS 复刻）

| 组件 | 原型类名 | 说明 |
|------|---------|------|
| Button | `.btn` | primary/default/error，text 文字按钮（行操作用），24/32/40px 高度 |
| Input | `.input` | 32px，focus 主色边框 + ring |
| Select | `.select` | 下拉选择（筛选项用，clearable） |
| Status Tag | `.maintenance-status` | 边框 + 浅底 + 色字，24px 高、2px 圆角 |
| Card | `.maintenance-card` | 白底、8px 圆角、无边框、轻阴影 |
| DataTable | `.maintenance-table` | 表头 38px/#f9f9f9/#999、行 38px |
| Pagination | `.pagination` | 表格底部分页，统计与页码同行 |
| Modal | `.modal` | PageDialog 封装，640px 默认宽 |
| Tabs | `.tabs` | 页签栏 |
| Breadcrumb | `.breadcrumb` | 面包屑 |
| Tooltip | `.tooltip` | 悬停提示（省略文本列必配） |

### 1.2 maintenance-pc 业务组件（原型需复刻其结构）

| 组件 | 说明 |
|------|------|
| PageSearchCard | 筛选卡：内联筛选项 + 右上角 搜索/重置 + 超行自动折叠 |
| PageFilterField | 筛选项：label 左对齐 + 内容区（统一宽度） |
| PageTableCard | 表格卡：工具栏（新增/批量删除/刷新/列设置）+ 表格 + 底部分页 |
| PageDialog | 业务弹窗：标题主色、确认/取消、mask 不可点击关闭 |
| PageKeywordSearch | 关键字搜索（左侧下拉 + 输入框，总宽 280px） |
| AppSelect | 下拉选择器（筛选项标准控件） |
| TableHeaderOperation | 表格工具栏按钮组（新增 ghost primary / 批量删除 ghost error + Popconfirm / 刷新 / 列设置） |
| MaintenanceStatusTag | 状态标签（.maintenance-status 类） |
| PrototypeNote | 标注角标（.maintenance-rule-note__badge，20px 圆形主色白字） |

---

## 2. 列表页模式（核心 Recipe，对应列表类型页面开发规则）

### 2.1 页面结构

```html
<div class="maintenance-page">
  <!-- 页面标题区 -->
  <div class="maintenance-page__header">
    <div>
      <h1 class="maintenance-page__title">工单中心</h1>
      <div class="maintenance-page__subtitle">查看全量维保工单，并处理无匹配、改派和质保异常</div>
    </div>
  </div>
  <!-- 筛选卡 -->
  <div class="maintenance-card page-search-card">
    <!-- 筛选项 + 右上角 搜索/重置 -->
  </div>
  <!-- 表格卡 -->
  <div class="maintenance-card page-table-card">
    <!-- 工具栏 + 表格 + 分页 -->
  </div>
</div>
```

### 2.2 必须遵守的规则

- **页面根容器不加 `overflow-hidden`**，滚动由布局内容区承担（scrollMode=content）
- **筛选项宽度禁止自定义**：统一 PageSearchCard 默认值（field 270px / content 190px），保证各列表页筛选密度一致
- **固定含义的关键字搜索不用左侧下拉**：label 直接表达字段含义（如"商户信息"），placeholder 写可搜索内容（如"商户名称/联系人/电话"）
- **搜索按钮** = 页码回第一页后请求数据；**重置按钮** = 清空条件 + 页码回第一页后请求数据
- **工具栏按钮**（新增/批量删除/刷新/列设置）用组件配置控制显隐，**禁止 CSS 隐藏**
- **列宽显式声明**；适合自适应的主文本列用弹性列（fluid-column-key）
- **普通文本列**单行省略 + 悬停 tooltip；多行内容列必须覆盖 td 的 `white-space: nowrap`
- **状态字段**固定宽度；标签/状态点严格按参考图渲染，**不互换**
- **操作列** `key='operate'`、`fixed: 'right'`、text 按钮；按钮多时加列宽，**不压缩按钮间距**
- **分页**在表格底部，统计与页码保持同一行
- **冻结列**时表格卡及祖先容器禁止 overflow:hidden（冻结列 overlay 会被裁切）
- **脱敏字段** mock 存完整值，组件控制展示（默认 `135****6464`，点眼睛切换完整值）

---

## 3. 组件详细规范

### 3.1 按钮

| 类型 | 用法 | 原型样式 |
|------|------|---------|
| 主按钮 | 搜索、提交、新增 | primary 底白字，hover #94c8ff，active #0b53d9 |
| 次按钮 | 重置、取消 | 白底、1px #e5e5e5 边框、#333 文字 |
| 危险按钮 | 删除 | error 底白字（ghost 样式用于批量删除） |
| 文字按钮 | 行操作（查看/编辑/删除） | text primary/error，无块状内边距 |

尺寸：small 24px / medium 32px / large 40px；行操作统一 small text。

**DO**：列表行操作用 text 按钮，主次层级分明。
**DON'T**：行操作使用带块状内边距的按钮；每个按钮都是主按钮。

### 3.2 输入框

- 高度 32px，白底，1px #e5e5e5 边框，4px 圆角
- focus：边框变主色 + 主色 ring
- placeholder #cccccc；筛选项输入框带 clearable 清空图标
- 筛选项 label 左对齐（labelWidth 72px），**不用 placeholder 当 label**

### 3.3 选择器（AppSelect / NSelect）

- 高度 32px，与输入框一致
- 筛选项使用：`clearable` + `options` + placeholder
- 选项数据：状态/类型等枚举用 `[{ label, value }]` 数组

### 3.4 筛选卡 PageSearchCard

| 规格 | 值 |
|------|-----|
| 容器 | 白卡、无边框、8px 圆角、轻阴影，content padding 18px 20px |
| 布局 | 内联 flex wrap，gap 12px 16px |
| 筛选项 | label 72px 左对齐、field 宽 270px、内容区 190px |
| 操作区 | 固定右上角（预留 200px）：搜索（primary small）+ 重置（default small）+ 展开/收起（text primary small） |
| 折叠 | 筛选项超一行自动显示收起按钮（collapsible） |

原型结构（类名可简化，规格必须一致）：

```html
<div class="page-search-card">
  <div class="filter-field">
    <label>工单信息</label>
    <div class="filter-content"><input class="input" placeholder="工单号/门店名称/门店编码/类目"></div>
  </div>
  <!-- 更多筛选项 ... -->
  <div class="filter-actions">
    <button class="btn btn-primary">搜索</button>
    <button class="btn">重置</button>
  </div>
</div>
```

### 3.5 表格卡 PageTableCard

| 规格 | 值 |
|------|-----|
| 工具栏 | 左侧 prefix 插槽（自定义按钮）+ 右侧 新增（ghost primary small）/ 批量删除（ghost error small + Popconfirm）/ 刷新（small）/ 列设置（small） |
| 表头 | 38px 高、#f9f9f9 底、#999 文字、400 字重 |
| 行 | 38px 高，hover 浅底 |
| 文本列 | 单行省略 + tooltip |
| 操作列 | 右冻结，text 按钮，间距统一不换行 |
| 分页 | 底部，统计 + 页码同行 |

### 3.6 状态标签 .maintenance-status

```html
<span class="maintenance-status maintenance-status--primary">质保内-上门服务</span>
```

- inline-flex、height 24px、padding 0 8px、12px 字号、1px 边框、2px 圆角
- 语义类：`--primary` / `--success` / `--warning` / `--error` / `--purple`（border=色值、bg=浅底、color=色值）、`--default`（color #999）
- 标签与状态点严格按参考图，不互换

### 3.7 弹窗 PageDialog

- 标题主色、默认宽 640px、8px 圆角
- 内容区 + 底部操作区（右下角：取消 + 确认/主按钮）
- 确认按钮支持 loading 态；mask-closable 默认 false（点击遮罩不关闭）
- 提交成功用 Toast 反馈，失败用 warning Toast（如"请选择目标服务商并填写人工派单原因"）

### 3.8 反馈 Toast

- 页面右上角浮层，success / warning / error 三态
- 语义色：success #00b87a、warning #ff9000、error #ff3325
- 禁止使用浏览器原生 `alert()/confirm()/prompt()`

### 3.9 汇总卡 / 详情（详情页、工作台）

- 汇总卡：4 列 grid gap 16px；item 白底 1px 边框 8px 圆角 padding 16px；label 12px/#999，value 24px/600/#333
- 详情 grid：3 列 grid gap 18px 24px；label 12px/#999，value 14px/#333
- 区块标题：16px/600 + 3×16px 主色竖条前缀
- 提示条：主色 1px 边框 + 主色浅底 + 13px/#666

### 3.10 标注角标 PrototypeNote

- 20×20 圆形、主色底白字、11px/600、cursor help
- hover 显示 tooltip（标注类型 + 内容），点击展开标注侧边栏
- 目标元素需 `position: relative`，角标 `absolute; top: -6px; right: -6px`

---

## 4. AI Slop 防护（组件级）

- ❌ 行操作使用块状按钮（用 text 按钮）
- ❌ 筛选 label 缺失、placeholder 当 label
- ❌ 页面根容器加 overflow-hidden（冻结列裁切）
- ❌ 用 CSS 隐藏表格工具栏按钮（用配置控制）
- ❌ 状态标签与状态点互换（严格按参考图）
- ❌ 表格列宽全部自适应（显式声明，主文本列才弹性）
- ❌ 操作列按钮间距被压缩（加列宽）
- ❌ 脱敏数据在 mock 中只存脱敏值（存完整值，组件控制展示）

---

## 5. 页面状态

- **空状态**：必须有引导文案 + 操作按钮（如"暂无工单数据"+ 刷新按钮），禁止纯文字
- **加载态**：表格 loading（骨架行/遮罩），搜索后模拟 350ms 延迟
- **弹窗提交态**：确认按钮 loading，成功后关闭 + Toast
