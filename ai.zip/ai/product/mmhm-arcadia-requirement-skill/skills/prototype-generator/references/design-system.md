# prototype-generator references — maintenance-pc 设计系统完整规范
# 来源：maintenance-pc 工程（Vue 3 + Vite + TypeScript + Naive UI + Pinia + Vue Router + UnoCSS）
# 参考工程路径：/Users/mmhm/busyming-engineer-prd/apps/maintenance-pc
# 主题来源：src/theme/settings.ts（themeColor #0073FF）、src/styles/css/maintenance.css（--maintenance-* 变量）
# 页面规范：docs/列表类型页面开发规则.md
# 原型生成时统一映射为 --brand-* 前缀（保持与 prototype-generator 兼容）

---

## 1. Token 前缀规范

maintenance-pc 设计 Token 分两层：

- **Naive UI 主题变量**（settings.ts → `naiveui.*`）：驱动 NButton / NCard / NDataTable 等组件；
- **项目层 CSS 变量** `--maintenance-*`（src/styles/css/maintenance.css）：驱动 maintenance-page / maintenance-status / maintenance-summary 等页面样式。

原型生成时统一映射为 `--brand-*` 前缀。

**映射关系**：
- `--brand-primary` ← `--maintenance-primary: #0073ff`（= themeSettings.themeColor）
- `--brand-*-bg` 语义浅底 ← `--maintenance-*-light` 系列
- `--brand-text-*` ← `--maintenance-text*`（= Naive textColor1/2/3）
- `--brand-border` ← `--maintenance-border: #e5e5e5`（= Naive borderColor/dividerColor）
- `--brand-page-background` ← `--maintenance-bg: #f2f2f2`（= Naive bodyColor）

---

## 2. 语义主色

| Token | 值 | 说明 |
|-------|---|------|
| `--brand-primary` | #0073ff | 主色（themeSettings.themeColor） |
| `--brand-primary-hover` | #94c8ff | hover 态（naiveui primaryColorHover） |
| `--brand-primary-active` | #0b53d9 | 按下态（naiveui primaryColorPressed） |
| `--brand-primary-bg` | #e6f3ff | 浅底（naiveui primaryColorSuppl = --maintenance-primary-light） |
| `--brand-success` | #00b87a | 成功 |
| `--brand-warning` | #ff9000 | 警告 |
| `--brand-error` | #ff3325 | 错误/危险 |
| `--brand-info` | #0073ff | 信息（isInfoFollowPrimary=true，跟随主色） |
| `--brand-purple` | #7d4fd6 | 紫色扩展（--maintenance-purple，非 Naive 语义色） |

### 2.1 语义浅底（--maintenance-*-light）

| Token | 值 |
|-------|---|
| `--brand-primary-bg` | #e6f3ff |
| `--brand-success-bg` | #e6f8f2 |
| `--brand-warning-bg` | #fff4e6 |
| `--brand-error-bg` | #ffebe9 |
| `--brand-purple-bg` | #f2ecff |

---

## 3. 文本色

| Token | 值 | 说明 |
|-------|---|------|
| `--brand-text-heading` / `--brand-text-primary` | #333333 | 标题、正文（Naive textColor1 / --maintenance-text） |
| `--brand-text-secondary` | #666666 | 次要文字（Naive textColor2） |
| `--brand-text-tertiary` / `--brand-text-muted` | #999999 | 辅助文字（Naive textColor3） |
| `--brand-text-placeholder` | #cccccc | 占位符（Naive placeholderColor） |

---

## 4. 背景 / 填充

| Token | 值 | 说明 |
|-------|---|------|
| `--brand-page-background` | #f2f2f2 | 页面底色（Naive bodyColor / --maintenance-bg） |
| `--brand-surface` | #ffffff | 卡片/面板白底（--maintenance-surface） |
| `--brand-surface-light` | #f9f9f9 | 表头背景（DataTable thColor / --maintenance-surface-light） |

---

## 5. 边框

| Token | 值 | 说明 |
|-------|---|------|
| `--brand-border` | #e5e5e5 | 默认边框/分割线（Naive borderColor = dividerColor） |
| `--brand-border-light` | #ebebeb | 浅边框（表内分割线、布局分隔） |
| `--brand-border-strong` | #d9d9d9 | 深边框（hover 边框、强调分隔） |

---

## 6. 字体体系

| 用途 | 规格 | 来源 |
|------|------|------|
| 页面标题 | 18px / 600 / 行高 32px | maintenance-page__title |
| 区块标题 | 16px / 600 | maintenance-section-title |
| 正文 | 14px / 400 | Naive 默认 font-size |
| 表头 | 12px / 400 / #999 | Naive thTextColor、thFontWeight=400 |
| 辅助文字 | 12px / 400 | maintenance-page__subtitle 等 |
| 大数字 | 24px / 600 | maintenance-summary-item__value |
| 字体栈 | 'PingFang SC', 'Microsoft YaHei', sans-serif | 全局 |

---

## 7. 圆角

| Token | 值 | 说明 |
|-------|---|------|
| `--brand-radius-sm` | 2px | 状态标签（maintenance-status）、小徽标 |
| `--brand-radius-md` | 4px | 按钮、输入框、默认圆角（themeSettings.themeRadius=4） |
| `--brand-radius-lg` | 8px | 卡片、Modal、Drawer（naiveui Card/Dialog/Modal/Drawer borderRadius=8px） |

---

## 8. 阴影

| 用途 | 值 | 说明 |
|------|---|------|
| page-card | `0 1px 4px rgba(0, 21, 41, 0.08)` | maintenance-card 轻阴影 |
| Modal/浮层 | `0 4px 12px rgba(0, 0, 0, 0.15)` | 弹层阴影 |
| 侧边栏 | `2px 0 8px 0 rgba(29, 35, 41, 0.05)` | settings.ts 布局阴影配置 |

---

## 9. 布局参数（themeSettings.layout / sider / tab）

| 参数 | 值 | 说明 |
|------|---|------|
| 布局模式 | top-hybrid-header-first | 顶部一级菜单 + 左侧子菜单 |
| Header 高度 | 60px | 顶部栏：Logo + 一级菜单 + 面包屑/用户入口 |
| 页签栏高度 | 40px | chrome 样式页签，fixedHeaderAndTab=true |
| Sider 宽度 | 240px | 左侧子菜单（收起 50px；mixChildMenuWidth 200px） |
| 滚动模式 | content | 内容区滚动，页面根容器禁止 overflow-hidden |
| 页脚 | 不显示 | footer.visible=false |

---

## 10. 组件尺寸

| 组件 | 值 |
|------|---|
| Button tiny/small | 24px |
| Button medium | 32px |
| Button large | 40px |
| 输入框 | 32px |
| DataTable th / td | 38px |

---

## 11. 数据表格（naiveui DataTable 覆盖）

| Token/规格 | 值 | 说明 |
|-----------|-----|------|
| thHeight | 38px | 表头高度 |
| tdHeight | 38px | 行高 |
| thColor | #f9f9f9 | 表头背景 |
| thTextColor | #999999 | 表头文字 |
| thFontWeight | 400 | 表头不加粗 |
| 文本列 | 单行省略 + tooltip | ellipsis: { tooltip: true } |
| 操作列 | key='operate'，fixed right | text 按钮，间距统一不换行 |

---

## 12. maintenance-pc 页面模式（maintenance.css）

### 12.1 页面容器 `.maintenance-page`

flex column、gap 16px、min-height 100%，页面根容器不加 overflow-hidden。

### 12.2 页面标题区 `.maintenance-page__header`

- 标题 `__title`：18px/600、#333、行高 32px
- 副标题 `__subtitle`：12px、#999
- 右侧可放操作按钮（justify-content: space-between）

### 12.3 区块标题 `.maintenance-section-title`

16px/600，`::before` 伪元素 3×16px 主色竖条（2px 圆角），gap 8px，margin-bottom 16px。

### 12.4 汇总卡 `.maintenance-summary-grid`

- 4 列 grid，gap 16px
- item：白底、1px 边框、8px 圆角、padding 16px
- label：12px、#999；value：24px/600/#333、margin-top 8px

### 12.5 详情 grid `.maintenance-detail-grid`

3 列 grid，gap 18px 24px；label 12px/#999、margin-bottom 4px；value 14px/#333、min-height 22px。

### 12.6 状态标签 `.maintenance-status`

inline-flex、height 24px、padding 0 8px、12px 字号、1px 边框、2px 圆角、white-space nowrap。
语义类：`--primary` / `--success` / `--warning` / `--error` / `--purple`（边框=色值、背景=浅底、文字=色值）、`--default`（文字 #999）。

### 12.7 提示条 `.maintenance-tip`

主色 1px 边框、主色浅底、13px/#666、padding 10px 12px、4px 圆角。

### 12.8 标注角标 `.maintenance-rule-note__badge`

20×20 圆形、主色底白字、11px/600、cursor: help —— 原型标注角标（A001 等）按此样式渲染。

---

## 13. 设计原则

- **所有色值通过 CSS 变量引用**，禁止硬编码 hex
- 原型类名统一映射 `--brand-*`；页面结构类名对应 maintenance-pc（.maintenance-page / .maintenance-card / .maintenance-status）
- **参考工程是 UI 还原唯一标准**：标签与状态点不互换、按钮颜色不改（列表类型页面开发规则 §10）
- 列表页禁止给表格卡及其祖先容器加 overflow:hidden（冻结列会被裁切）
- 筛选项宽度统一，不在页面自定义（由 PageSearchCard 默认值控制）
