---
name: prototype-generator
version: 1.0.0
description: 读取需求文档（MD），生成高保真可交互HTML原型。采用多页源文件+组装单HTML架构，内置 mmhm-arcadia-requirement 元数据，maintenance-pc参考工程设计系统，纯CSS实现，可选 mmhm-arcadia-requirement 导入。
author: taobq
agent_created: true
---

# Prototype Generator v2

从需求文档生成高保真可交互的 HTML 原型。**多页源文件生成 → 组装为单 HTML 输出**，兼顾 AI 修改效率和 mmhm-arcadia-requirement 导入便利。

> **规范源**：原型文件格式、设计系统接口（DesignSystem）、meta 标签关联规范见 `mmhm-arcadia-requirement-rules` §3；YAML front matter 字段定义见 `mmhm-arcadia-requirement-rules` §2.2。本 Skill 侧重生成执行逻辑。
> **设计系统**：参考 maintenance-pc 工程（Vue 3 + Vite + TypeScript + Naive UI + UnoCSS，位于 `/Users/mmhm/busyming-engineer-prd/apps/maintenance-pc`），使用纯 CSS + CSS 变量实现，不使用 Tailwind。参考工程的页面开发规范见其 `docs/列表类型页面开发规则.md`，样式变量见其 `src/styles/css/maintenance.css`。

## 核心架构：多页源文件 + 组装

```
生成过程（AI 按页工作，上下文可控）：
  pages/
  ├── page-list.html      ← 列表页（AI独立生成/修改）
  ├── page-detail.html    ← 详情页
  └── page-form.html      ← 表单页

组装输出（mmhm-arcadia-requirement 可直接导入）：
  prototype-web.html      ← 单文件，含所有页面 + 路由 + 共享样式
```

**为什么这么做**：
- 单 HTML >1500 行时 AI 难定位修改 → 源文件按页拆分，AI 改单页
- mmhm-arcadia-requirement 只认 `prototype-web.html` 单文件 → 组装步骤拼成单文件
- 组装是纯机械拼接，AI 可靠执行不幻觉

---

## 执行流程

```
Step 1: 采集设计系统 → Step 2: 解析需求 → Step 3: 确认页面 → Step 4: 逐页生成 → Step 5: 组装 → Step 6: 可选导入
```

### Step 1: 采集设计系统

**优先级顺序**（高→低）：

1. **用户直接提供** designSystem 对象 → 直接使用
2. **项目根目录** `.design-system.json` 文件 → 读取使用
3. **mmhm-arcadia-requirement Settings** → `GET http://arcadia.busyming.com/api/settings` 读取
4. **默认 maintenance-pc 色系** → 内置于本 Skill（见下方）

向用户确认设计系统来源：
```
🎨 设计系统：
- 检测到项目 .design-system.json → 使用项目配置
- 或使用 maintenance-pc 参考工程色系（primary #0073ff + 中性灰）
是否使用该配置？还是提供自定义设计系统？
```

**默认设计系统**（详细规范见 `references/design-system.md`）：

> 注：默认设计系统是 `mmhm-arcadia-requirement-rules` §3.2 `DesignSystem` 接口的 maintenance-pc 参考工程实现。

| Token | 色值 | 用途 |
|-------|------|------|
| --brand-primary | #0073ff | 主按钮、导航激活、CTA |
| --brand-page-background | #f2f2f2 | 页面底色 |
| --brand-surface | #ffffff | 卡片/面板白底 |
| --brand-text-primary | #333333 | 一级正文 |
| --brand-text-heading | #333333 | 标题/强调 |
| --brand-border | #e5e5e5 | 边框/分割线 |
| --brand-success | #00b87a | 成功状态 |
| --brand-error | #ff3325 | 错误/危险 |

### Step 2: 解析需求文档

读取 MD 需求文档，提取关键信息：

| 提取项 | 来源章节 | 用途 |
|--------|---------|------|
| 需求 ID / 标题 / 平台 | YAML front matter | 嵌入 meta + HTML title |
| 页面列表 | `## 页面设计` | 逐页生成依据 |
| 功能结构 | `## 功能结构` (flowchart LR) | 导航结构 |
| 业务流程 | `## 业务流程` (flowchart TD) | 交互逻辑依据 |
| 需求说明 | `## 需求说明` | 组件行为定义 |
| 标注说明 | `## 标注说明` | 原型可视化标注依据 |

**如果文档缺少 `## 页面设计`**：根据功能结构图和需求说明推导页面列表，向用户确认。

### Step 3: 确认页面列表

```
📐 根据需求文档，推导出以下页面：
1. 列表页 — 订单列表，含筛选/搜索/分页
2. 详情页 — 订单详情，含状态流转
3. 表单页 — 新建/编辑订单

请确认页面列表，或补充调整。
```

### Step 4: 逐页生成（源文件）

每个页面生成一个独立片段文件到 `pages/` 目录。

**源文件结构**（不是完整 HTML，是页面片段）：

```html
<!-- PAGE: 列表页 | ID: page-list -->
<div id="page-list" class="page-section">
  <!-- 页面标题区 -->
  <div class="maintenance-page__header">
    <div>
      <h1 class="maintenance-page__title">订单管理</h1>
      <div class="maintenance-page__subtitle">维护全量订单，支持筛选与批量操作</div>
    </div>
    <button onclick="navigate('page-form')" class="btn btn-primary">新建订单</button>
  </div>
  <!-- 筛选卡 -->
  ...
  <!-- 表格卡 -->
  ...
</div>

<script>
// page-list 专属交互逻辑
</script>
```

**生成规则**:
- 外层用 `<div id="page-xxx" class="page-section">` 包裹
- **使用纯 CSS + CSS 变量**（`var(--brand-*)`），**禁止使用 Tailwind，禁止硬编码 hex**
- 导航跳转用 `navigate('page-xxx')`
- 页面 JS 放 `<script>` 标签
- 不写 `<html>/<head>/<body>`
- 行内注释标记区块（`<!-- 搜索栏 -->`），方便后续定位
- **标注处理**：如需求文档有 `## 标注说明`，根据 `目标位置` 匹配到对应元素，添加 `data-annotation-id="A001"` 属性。标注渲染由组装步骤统一注入 CSS/JS，单页生成时不处理样式

**组件代码参考** → 详见 `references/component-spec.md`，对应 maintenance-pc 组件：
- 按钮（主/次/危险/文字，24/32/40px 高度）含 DO/DON'T
- 输入框（标准/筛选项/下拉）含焦点状态
- 数据展示（表格/状态标签 maintenance-status/汇总卡/详情 grid）
- 布局（顶部一级菜单 + 左侧子菜单 + 页签栏 + 内容区）
- 列表页模式（页面标题区 + PageSearchCard 筛选卡 + PageTableCard 表格卡）
- 反馈（Toast/PageDialog）
- 页面状态（空状态/骨架屏）

### Step 5: 组装为单 HTML

将所有页面片段组装为 `prototype-web.html`。

**组装模板关键部分**：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="mmhm-arcadia-requirement-id" content="{REQ_ID}">
  <title>{需求标题} - 原型</title>
  <style>
    /* ═════ 设计 Token（maintenance-pc 参考工程） ═════ */
    :root {
      --brand-page-background: #f2f2f2;
      --brand-surface: #ffffff;
      --brand-surface-secondary: #f9f9f9;
      --brand-surface-light: #f9f9f9;
      --brand-surface-muted: #f2f2f2;
      --brand-border: #e5e5e5;
      --brand-border-light: #ebebeb;
      --brand-border-strong: #d9d9d9;
      --brand-text-heading: #333333;
      --brand-text-primary: #333333;
      --brand-text-secondary: #666666;
      --brand-text-tertiary: #999999;
      --brand-text-body: #666666;
      --brand-text-muted: #999999;
      --brand-text-placeholder: #cccccc;
      --brand-primary: #0073ff;
      --brand-primary-bg: #e6f3ff;
      --brand-primary-hover: #94c8ff;
      --brand-primary-active: #0b53d9;
      --brand-success: #00b87a;
      --brand-success-bg: #e6f8f2;
      --brand-warning: #ff9000;
      --brand-warning-bg: #fff4e6;
      --brand-error: #ff3325;
      --brand-error-bg: #ffebe9;
      --brand-purple: #7d4fd6;
      --brand-purple-bg: #f2ecff;
      --brand-header-height: 60px;
      --brand-sider-width: 240px;
      --brand-tabbar-height: 40px;
      --brand-radius-sm: 2px;
      --brand-radius-md: 4px;
      --brand-radius-lg: 8px;
    }
    /* ═════ 基础重置 ═════ */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
      font-size: 14px; color: var(--brand-text-primary);
      background: var(--brand-page-background); line-height: 1.5;
    }
    /* ═════ 布局（顶部一级菜单 + 左侧子菜单 + 页签栏） ═════ */
    .layout { display: flex; flex-direction: column; height: 100vh; }
    .layout-header { flex-shrink: 0; height: var(--brand-header-height); padding: 0 16px; display: flex; align-items: center; gap: 24px; background: var(--brand-surface); border-bottom: 1px solid var(--brand-border-light); }
    .layout-body { flex: 1; min-height: 0; display: flex; }
    .layout-sider { width: var(--brand-sider-width); flex-shrink: 0; display: flex; flex-direction: column; background: var(--brand-surface); border-right: 1px solid var(--brand-border-light); }
    .layout-right { flex: 1; min-width: 0; display: flex; flex-direction: column; }
    .layout-tabbar { flex-shrink: 0; height: var(--brand-tabbar-height); background: var(--brand-surface); border-bottom: 1px solid var(--brand-border-light); }
    .layout-content { flex: 1; min-height: 0; overflow: auto; padding: 16px; }
    .page-section { display: none; }
    .page-section.active { display: block; }
    /* ═════ 组件样式（从 component-spec.md 引用） ═════ */
    /* ... 按钮、输入框、表格、分页等组件样式 ... */
  </style>
</head>
<body>
  <div class="layout">
    <header class="layout-header">
      <div class="header-logo">{系统名称}</div>
      <nav class="header-menu" id="header-menu">
        <!-- 一级菜单 -->
      </nav>
    </header>
    <div class="layout-body">
      <aside class="layout-sider">
        <nav class="sider-menu" id="sider-menu">
          <!-- 二级子菜单 -->
        </nav>
      </aside>
      <div class="layout-right">
        <div class="layout-tabbar" id="layout-tabbar">
          <!-- 页签栏 -->
        </div>
        <main class="layout-content">
          {{PAGE_FRAGMENTS}}
        </main>
      </div>
    </div>
  </div>
  <div id="toast-container"></div>
  <script>
    function navigate(pageId) { /* 路由切换 + 一级菜单/子菜单/页签高亮同步 */ }
    function showToast(msg, type) { /* 全局 Toast */ }
    navigate('page-list'); // 初始页面
  </script>
</body>
</html>
```

**组装规则**:
1. 页面 `<div>` 片段插入 `<main class="layout-content">`
2. 页面 `<script>` 合并到 `</body>` 前
3. 全局路由 `navigate()` + Toast + 一级菜单/子菜单/页签高亮同步
4. `<meta name="mmhm-arcadia-requirement-id">` 嵌入需求 ID
5. `:root` 填入设计系统 CSS 变量（如有自定义 designSystem，覆盖对应变量值）
6. 组件样式（按钮、输入框、表格、分页等）在 `<style>` 中统一注入（从 component-spec.md 引用）
7. **标注渲染（如需求含 `## 标注说明`）**：
   - 注入标注样式：数字角标（圆形，primary 背景，白字，12px）
   - 注入标注交互：hover 角标显示 tooltip（含类型 + 内容），点击角标展开侧边栏标注列表
   - 标注角标定位：`position: absolute; top: -6px; right: -6px;`（目标元素需 `position: relative`）
   - 标注数据从 `## 标注说明` 表格解析，注入为全局 JS 数组 `window.__annotations`

### Step 6: mmhm-arcadia-requirement 桥接（可选）

```
若 http://arcadia.busyming.com 可达：
  POST /api/requirements/{id}/prototype/import
  Body: { "content": "<完整HTML>", "platform": "web" }

若不可达：
  保存 prototype-web.html 到当前工作目录
```

---

## 设计规范（精要）

详细规范见 `references/design-system.md`，这里只列核心规则：

### 圆角：三级体系（maintenance-pc themeRadius=4 派生）
- `--brand-radius-sm`（2px）：状态标签、小徽标（maintenance-status）
- `--brand-radius-md`（4px）：按钮、输入框、默认圆角（themeRadius）
- `--brand-radius-lg`（8px）：卡片、Modal、Drawer（Naive Card/Modal borderRadius）

### 背景
- 页面底色：`var(--brand-page-background)`（#f2f2f2，Naive bodyColor）
- 卡片/surface：`var(--brand-surface)`（#ffffff）
- 输入框背景：#fff（白色）
- 表头背景：`var(--brand-surface-light)`（#f9f9f9，DataTable thColor）

### 字体
- 页面标题：18px font-weight 600（maintenance-page__title，行高 32px）
- 区块标题：16px font-weight 600（maintenance-section-title，前缀 3×16px 主色竖条）
- 正文：14px font-weight 400
- 表头：12px font-weight 400（#999，Naive thFontWeight=400）
- 辅助文字：12px font-weight 400
- 字体栈：'PingFang SC', 'Microsoft YaHei', sans-serif

### 间距
- 紧凑（同组）：8px
- 标准（区块间）：16px（maintenance-page 内容间距 gap 16px）
- 宽松（大区块）：24px

### 阴影
- page-card 默认：`0 1px 4px rgba(0, 21, 41, 0.08)`（maintenance-card）
- Modal/浮层：`0 4px 12px rgba(0, 0, 0, 0.15)`

### 布局
- 顶部一级菜单 Header（60px） + 左侧子菜单 Sider（240px） + 页签栏（40px） + 内容区（flex:1，内容区滚动）
- 页面容器 `.maintenance-page`（flex column，gap 16px），页面标题区 `.maintenance-page__header`（标题 18px/600 + 副标题 12px/#999）
- 所有内容卡用 `.maintenance-card`（白底、8px 圆角、无边框、轻阴影）
- 列表页采用 common-table 模式：页面标题区 + 筛选卡（PageSearchCard） + 表格卡（PageTableCard，工具栏 + 表格 + 底部分页）

---

## 修改工作流

用户要求修改原型时：

1. **定位**：确定修改哪个页面（对应 `pages/page-xxx.html` 源文件）
2. **修改源文件**：只改该页面的片段文件
3. **重新组装**：将所有页面片段重新拼成 `prototype-web.html`
4. **可选导入**：如有 mmhm-arcadia-requirement，调用 prototype import API

**若用户直接给修改指令未指定页面**：根据修改内容判断涉及哪个页面，明确告知。

---

## 移动端原型

`prototype-mobile.html` 默认不生成，用户显式要求时才生成。

| 差异点 | Web 端 | 移动端 |
|--------|--------|--------|
| 宽度 | 响应式 1024px+ | 固定 375px |
| 布局 | 顶部一级菜单 + 左侧子菜单 + 页签 + 内容区 | 无侧边栏，顶部导航 |
| 导航 | 侧边栏菜单 | 底部 Tab |
| 按钮 | 8px 圆角 | 全宽 |
| 列表项 | 紧凑 | min-height 44px |
| 弹窗 | 居中 Modal | 底部 Bottom Sheet |

---

## AI Slop 防护（关键）

AI 生成原型时最常见的“AI味”错误，**绝对不能出现**：

- ❌ 使用 Tailwind CDN 或 Tailwind 类名（如 `bg-blue-500`、`flex items-center`）
- ❌ 硬编码 hex 色值（用 CSS 变量 `var(--brand-*)` 引用）
- ❌ 所有内容都包卡片（间距和对齐本身就能分组）
- ❌ 嵌套卡片
- ❌ `alert()` / `confirm()` / `prompt()`（用自定义 Modal/Toast）
- ❌ placeholder 当 label
- ❌ 纯文字空状态（必须带引导文案+操作按钮）
- ❌ 每个按钮都是主按钮（要有主次层级）
- ❌ 使用陶土色/暖灰色系（本项目使用 maintenance-pc 蓝灰色系）

---

## 输出质量检查清单

组装完成后自检（必须全部通过）：

- [ ] 单个 `prototype-web.html`，可独立在浏览器打开
- [ ] `<meta name="mmhm-arcadia-requirement-id">` 已嵌入
- [ ] 所有页面通过 `navigate()` 可切换，菜单高亮同步
- [ ] 布局结构正确：顶部一级菜单 + 左侧子菜单 + 页签栏 + 内容区
- [ ] 按钮 hover/active/disabled 状态完整
- [ ] 输入框 focus 状态（border 变主色 + ring 效果）
- [ ] 至少一个表单有提交→加载→成功/失败的交互
- [ ] 真实文案，无“示例文字”“占位符”
- [ ] 色值用 CSS 变量（`var(--brand-*)`），无硬编码 hex
- [ ] 不使用 Tailwind CDN 或 Tailwind 类名
- [ ] 源文件 `pages/` 保留，方便后续修改
- [ ] 标注（如有）：目标元素含 `data-annotation-id`，角标可见，tooltip 内容正确，侧边栏列表完整

---

## 兼容性

标准 Agent Skill，兼容 WorkBuddy / Cursor / Trae / Claude Code / Codex。

## 与 prd-generator 的衔接

```
prd-generator 产出 requirement.md
  ↓ 读取
prototype-generator 提取页面列表 + 功能结构
  ↓ 逐页生成
pages/ → 组装 prototype-web.html
  ↓ 可选
mmhm-arcadia-requirement import API
```
