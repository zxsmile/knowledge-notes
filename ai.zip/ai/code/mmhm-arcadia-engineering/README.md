# Qoder Integration

This directory contains The Agency agents converted into **Qoder Skills** — one skill directory per agent, each containing a `SKILL.md` file.

Qoder discovers skills under `~/.qoder/skills/<skill-slug>/SKILL.md`. The skill slug is derived from the agent's display name (e.g. `Frontend Developer` → `frontend-developer`).

## Generated Format

Each generated skill lives at:

```text
integrations/qoder/<skill-slug>/SKILL.md
```

For example:

```text
integrations/qoder/frontend-developer/SKILL.md
integrations/qoder/backend-architect/SKILL.md
integrations/qoder/code-reviewer/SKILL.md
```

Each `SKILL.md` contains:

```markdown
---
name: frontend-developer
description: Expert frontend developer specializing in modern web technologies...
---

# Frontend Developer Agent Personality

You are **Frontend Developer**, an expert frontend developer...
```

The frontmatter is kept minimal (`name` + `description`) so it stays compatible with Qoder's skill loader. The Markdown body is copied unchanged from the source agent file.

## Install

### Option A: Install only Qoder skills

```bash
# 1. Generate Qoder Skill files
./scripts/convert.sh --tool qoder

# 2. Install to ~/.qoder/skills/
./scripts/install.sh --tool qoder
```

### Option B: Generate and install all supported tools at once

```bash
# 1. Generate integration files for all tools
./scripts/convert.sh

# 2. Install all tools (including Qoder)
./scripts/install.sh
```

## After Installation

Skills are installed to:

```text
~/.qoder/skills/frontend-developer/SKILL.md
~/.qoder/skills/backend-architect/SKILL.md
...
```

Qoder scans this directory automatically. If newly installed skills do not appear immediately:

- Restart Qoder, **or**
- Refresh the skill panel in Qoder settings

## Regenerate

Whenever you add or modify agents in the source directories, regenerate the Qoder skills:

```bash
./scripts/convert.sh --tool qoder
./scripts/install.sh --tool qoder
```

## Custom Install Path

To install skills to a custom location, set the `QODER_SKILLS_DIR` environment variable:

```bash
export QODER_SKILLS_DIR="$HOME/.qoder/skills"
./scripts/install.sh --tool qoder
```

Or use the `--path` override:

```bash
./scripts/install.sh --tool qoder --path /custom/path/to/skills
```

> **Note:** The generated files under `integrations/qoder/` are build output. Do not edit them directly — modify the source agent files under the division directories (e.g. `engineering/`, `design/`) and rerun `convert.sh`.
